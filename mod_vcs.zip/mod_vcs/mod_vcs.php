<?php
/**
 * VCS Payment Module
 */

// No direct access
defined('_JEXEC') or die;

// Include the syndicate functions only once
require_once dirname(__FILE__) . '/helper.php';
 
$vcsPay = new VCSPaymentHelper($params);

require JModuleHelper::getLayoutPath('mod_vcs');