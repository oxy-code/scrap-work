<?php
/**
 * @class   VCSPaymentHelper
 * @author  [codecygnus.com]
 * @version 1.0.0
 */

class VCSPaymentHelper {

	public $virtualTerminalId;
	public $uniqueTransactionNo;
	public $md5HASH;			// Hash
	public $transactionDesc;	// p3
	public $transactionAmt;		// p4
	public $occuranceCount; 	// p6
	public $occuranceFrequency; // p7
	//public $occuranceEmail;	// p11
	//public $occuranceAmount; 	// p13 - If the occurrence amount is omitted then the actual amount (p4) will be used by default.
	public $nextOccurDate; 		// NextOccurDate - Format: ccyy/mm/dd - irrespective of what the occurrence frequency is.
	public $urlsProvided;
	public $approvedUrl;
	public $declinedUrl;
	public $urlForCancelledTransaction; // p10


	function __construct($params) {
		$this->md5HASH 				= md5('codecygnus');
		$this->occuranceCount 		= 'U';
		$this->occuranceFrequency	= 'D'; // D - Daily and M - Monthly
		$this->virtualTerminalId	= $params->get('virtualID');
		$this->uniqueTransactionNo	= $this->generateTransCode(25);

		if ($params->get('approvedUrl') && $params->get('approvedUrl')) {
			$this->urlsProvided = 'Y';
		}

		$this->approvedUrl = ($params->get('approvedUrl')) ? $params->get('approvedUrl') : JURI::base();
		$this->declinedUrl = ($params->get('declinedUrl')) ? $params->get('declinedUrl') : JURI::base();
		$this->urlForCancelledTransaction = $this->declinedUrl;

		$jInput = JFactory::getApplication()->input;
		$this->transactionDesc 	= $jInput->getString('name', 'Package has not selected!');
		$this->transactionAmt 	= $jInput->get('amt', 0);
		$this->transactionAmt	= ($this->transactionAmt == 'free') ? 0 : $this->transactionAmt;
	}


	/**
	 * [debug description]
	 * @param  [type]  $data [description]
	 * @param  boolean $risk [description]
	 * @return [type]        [description]
	 */
	function debug($data, $risk = false) {
		echo "<pre>";
		if ($risk) { var_dump($data); } else { print_r($data); }
		echo "</pre>";
	}


	/**
	 * [generateTransCode description]
	 * @param  integer $length [description]
	 * @return [type]          [description]
	 */
	private function generateTransCode($length = 8) {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $transCode = '';
	    for ($i = 0; $i < $length; $i++) {
	        $transCode .= $characters[mt_rand(0, strlen($characters) - 1)];
	    }
	    return $transCode;
	}
}