<?php 
// No direct access
defined('_JEXEC') or die;
JHTML::_('behavior.formvalidator');
?>
<h3>Payment Form</h3><hr/>
<form method="POST" action="https://www.vcs.co.za/vvonline/vcspay.aspx">
	<input type="hidden" name="p1" value="<?php echo $vcsPay->virtualTerminalId; ?>">
	<input type="hidden" name="p2" value="<?php echo $vcsPay->uniqueTransactionNo; ?>">
	<input type="hidden" name="p3" value="<?php echo $vcsPay->transactionDesc; ?>">
	<input type="hidden" name="p4" value="<?php echo $vcsPay->transactionAmt; ?>">
	<input type="hidden" name="Budget" value="N">
	<input type="hidden" name="Hash" value="<?php echo $vcsPay->md5HASH; ?>">
	<input type="hidden" name="p6" value="<?php echo $vcsPay->occuranceCount; ?>">
	<input type="hidden" name="p7" value="<?php echo $vcsPay->occuranceFrequency; ?>">
	<input type="hidden" name="p10" value="<?php echo $vcsPay->urlForCancelledTransaction; ?>">
	
	<?php
		if($vcsPay->urlsProvided && $vcsPay->urlsProvided == 'Y') {
			$jInput = JFactory::getApplication()->input;
			
			echo '<input type="hidden" name="UrlsProvided" value="'.$vcsPay->urlsProvided.'">';
			echo '<input type="hidden" name="DeclinedUrl" value="'.$vcsPay->declinedUrl.'">';

			if($jInput->get('filter_package')) { // Needed only for supplier code project
				echo '<input type="hidden" name="ApprovedUrl" value="'.$vcsPay->approvedUrl.'?filter_package='.$jInput->get('filter_package').'">';
			}
			else {
				echo '<input type="hidden" name="ApprovedUrl" value="'.$vcsPay->approvedUrl.'">';
			}
		} 
	?>
	
	<div style="margin:auto;width:50%;" class = 'well'>
		<label>Order Detail</label><h3><?php echo $vcsPay->transactionDesc; ?></h3><br/>
		<label>Amount (in ZAR)</label><h3>R<?php echo $vcsPay->transactionAmt; ?></h3><br/>
		<label>Email address</label>
		<small class="help-block">(The receipt of this transaction will be sending to the below email address)</small>
		<input type="email" name="CardholderEmail" class="form-control" placeholder="Email">
		<input type="submit" value="Proceed to Payment">
	</div>
</form>